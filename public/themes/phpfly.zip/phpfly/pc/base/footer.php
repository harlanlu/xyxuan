<div class="fly-footer">
    <p> &copy; 2020 新意轩摄影 All Rights Reserved</p>
</div>
